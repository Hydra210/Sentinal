// SENTINEL Extension — Background Service Worker

const SENTINEL_URL = 'https://sentinal-totk.onrender.com';
const POLL_INTERVAL_MINUTES = 1;

chrome.alarms.create('sentinel-poll', { periodInMinutes: POLL_INTERVAL_MINUTES });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'sentinel-poll') return;

  try {
    const { profileId, connected } = await chrome.storage.local.get(['profileId', 'connected']);
    if (!connected) return;

    const pidParam = profileId ? `?profile_id=${profileId}&limit=5` : '?limit=5';
    const r = await fetch(`${SENTINEL_URL}/api/history${pidParam}`);
    if (!r.ok) return;
    const items = await r.json();

    const { lastSeenId } = await chrome.storage.local.get('lastSeenId');
    if (!items.length) return;

    const newest = items[0];
    if (lastSeenId && newest.id !== lastSeenId) {
      chrome.notifications.create({
        type:     'basic',
        iconUrl:  'icons/icon128.png',
        title:    'SENTINEL — Asset Archived',
        message:  `"${newest.audio_name}" (${newest.asset_type || 'Asset'}) by ${newest.display_name || newest.username} was archived.`,
        priority: 1,
      });
    }

    await chrome.storage.local.set({ lastSeenId: newest.id });
  } catch(e) {
    console.error('[SENTINEL BG]', e);
  }
});
