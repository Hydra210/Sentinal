// SENTINEL Extension — Background Service Worker

const POLL_INTERVAL_MINUTES = 1;

chrome.alarms.create('sentinel-poll', { periodInMinutes: POLL_INTERVAL_MINUTES });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'sentinel-poll') return;
  const { sentinelUrl } = await chrome.storage.local.get('sentinelUrl');
  if (!sentinelUrl) return;

  try {
    const r = await fetch(`${sentinelUrl}/api/history?limit=5`);
    if (!r.ok) return;
    const items = await r.json();

    const { lastSeenId } = await chrome.storage.local.get('lastSeenId');
    if (!items.length) return;

    const newest = items[0];
    if (lastSeenId && newest.id !== lastSeenId) {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'SENTINEL — Asset Archived',
        message: `"${newest.audio_name}" by ${newest.display_name || newest.username} was archived.`,
        priority: 1,
      });
    }

    await chrome.storage.local.set({ lastSeenId: newest.id });
  } catch (e) {
    console.error('[SENTINEL BG]', e);
  }
});
