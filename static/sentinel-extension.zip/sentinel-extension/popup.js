function esc(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function toast(msg) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3100);
}

function showScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + name).classList.add('active');
  document.getElementById('footer').style.display = name === 'dashboard' ? 'flex' : 'none';
}

const SENTINEL_URL = 'https://sentinal-totk.onrender.com';

async function sentinelFetch(method, path, body) {
  const opts = { method, headers: {} };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const r = await fetch(SENTINEL_URL + path, opts);
  const data = await r.json().catch(() => ({ detail: r.statusText }));
  if (!r.ok) throw new Error(data.detail || `HTTP ${r.status}`);
  return data;
}

// ── CONNECT ────────────────────────────────────────────────────────────────────
async function connectRoblox() {
  const code = document.getElementById('connect-code-input').value.trim();
  if (code.length !== 4) { toast('Enter the 4-digit code from your dashboard'); return; }

  showScreen('connecting');
  document.getElementById('connecting-msg').textContent = 'Reading Roblox session...';

  let cookie = null;
  try {
    const cookieObj = await chrome.cookies.get({
      url: 'https://www.roblox.com',
      name: '.ROBLOSECURITY'
    });
    if (cookieObj) cookie = cookieObj.value;
  } catch(e) { console.error(e); }

  if (!cookie) {
    toast('No Roblox session found — log into roblox.com first');
    showScreen('setup');
    return;
  }

  document.getElementById('connecting-msg').textContent = 'Validating code...';

  // Strip the Roblox cookie warning prefix if present
  if (cookie && cookie.includes('|_')) {
    cookie = cookie.split('|_').pop();
  }

  try {
    const r = await fetch(`${SENTINEL_URL}/api/connect-code/redeem`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, cookie }),
    });

    // Safely parse response — server may return plain text on errors
    const text = await r.text();
    let info;
    try { info = JSON.parse(text); }
    catch { throw new Error(`Server error: ${text.slice(0, 120)}`); }

    if (!r.ok) throw new Error(info.detail || `HTTP ${r.status}`);

    await chrome.storage.local.set({
      connected:   true,
      accountInfo: info,
      profileId:   info.profile_id || null,
    });

    document.getElementById('connecting-msg').textContent = '✓ Connected!';
    await new Promise(res => setTimeout(res, 600));

    await loadDashboard(info);
    showScreen('dashboard');
    toast('✓ Connected as ' + info.displayName);
  } catch(e) {
    toast('Failed: ' + e.message);
    showScreen('setup');
  }
}

// ── RE-DETECT ROBLOX ──────────────────────────────────────────────────────────
async function redetectRoblox() {
  showScreen('connecting');
  document.getElementById('connecting-msg').textContent = 'Re-detecting Roblox session...';

  let cookie = null;
  try {
    const cookieObj = await chrome.cookies.get({
      url: 'https://www.roblox.com',
      name: '.ROBLOSECURITY'
    });
    if (cookieObj) cookie = cookieObj.value;
  } catch(e) { console.error(e); }

  if (!cookie) {
    toast('No Roblox session — log into roblox.com on your bot account first');
    showScreen('setup');
    return;
  }

  toast('Got Roblox session — now get a fresh code from your dashboard');
  showScreen('setup');
  document.getElementById('connect-code-input').value = '';
  document.getElementById('connect-code-input').focus();
}

// ── DASHBOARD ──────────────────────────────────────────────────────────────────
async function loadDashboard(accountInfo) {
  const { profileId } = await chrome.storage.local.get('profileId');
  const pidParam = profileId ? `?profile_id=${profileId}` : '';

  if (accountInfo) {
    document.getElementById('ext-display-name').textContent = accountInfo.displayName || '—';
    document.getElementById('ext-username').textContent = '@' + (accountInfo.username || '—') + ' · UID ' + (accountInfo.userId || '—');
    const avatarEl = document.getElementById('ext-avatar');
    if (accountInfo.avatarUrl) {
      avatarEl.innerHTML = `<img src="${esc(accountInfo.avatarUrl)}" alt="">`;
    } else {
      avatarEl.textContent = (accountInfo.displayName || '?').charAt(0).toUpperCase();
    }
  }

  try {
    const [stats, status] = await Promise.all([
      sentinelFetch('GET', `/api/stats${pidParam}`),
      sentinelFetch('GET', `/api/status${pidParam}`),
    ]);

    document.getElementById('ext-stat-archived').textContent = stats.archived ?? 0;
    document.getElementById('ext-stat-dms').textContent      = stats.dms ?? 0;
    document.getElementById('ext-stat-groups').textContent   = stats.groups ?? 0;
    document.getElementById('ext-stat-wl').textContent       = stats.whitelisted ?? 0;

    const dot    = document.getElementById('status-dot');
    const toggle = document.getElementById('monitor-toggle');
    const sub    = document.getElementById('monitor-sub');

    if (status.monitoring) {
      dot.className = 'status-dot online';
      toggle.classList.add('on');
      sub.textContent = 'Actively polling groups';
    } else {
      dot.className = 'status-dot offline';
      toggle.classList.remove('on');
      sub.textContent = 'Monitoring is paused';
    }
  } catch(e) {
    document.getElementById('status-dot').className = 'status-dot offline';
    document.getElementById('monitor-sub').textContent = 'Could not reach server';
  }

  try {
    const { profileId } = await chrome.storage.local.get('profileId');
    const pidParam2 = profileId ? `?profile_id=${profileId}&limit=10` : '?limit=10';
    const items = await sentinelFetch('GET', `/api/history${pidParam2}`);
    const list  = document.getElementById('ext-history-list');
    if (!items.length) {
      list.innerHTML = '<div class="empty">No activity yet</div>';
    } else {
      list.innerHTML = items.map(item => `
        <div class="history-item">
          <div class="hi-top">
            <span class="hi-user">${esc(item.display_name || item.username)}</span>
            <span class="hi-time">${esc(item.time?.slice(5,16) || '')}</span>
          </div>
          <div class="hi-audio">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>
            </svg>
            ${esc(item.audio_name)}
            ${item.asset_type ? `<span style="opacity:0.5;margin-left:4px;">${esc(item.asset_type)}</span>` : ''}
            <span style="margin-left:auto;">${dmBadge(item.dm_status)}</span>
          </div>
        </div>`).join('');
    }
  } catch(e) {
    document.getElementById('ext-history-list').innerHTML = '<div class="empty">Could not load history</div>';
  }
}

function dmBadge(status) {
  if (status === 'sent')   return '<span class="badge badge-sent">DM ✓</span>';
  if (status === 'failed') return '<span class="badge badge-fail">DM ✗</span>';
  return '<span class="badge badge-na">N/A</span>';
}

async function toggleMonitor() {
  const toggle   = document.getElementById('monitor-toggle');
  const isOn     = toggle.classList.contains('on');
  const { profileId } = await chrome.storage.local.get('profileId');
  try {
    await sentinelFetch('POST', isOn ? '/api/monitoring/stop' : '/api/monitoring/start', { profile_id: profileId || '' });
    toggle.classList.toggle('on', !isOn);
    document.getElementById('monitor-sub').textContent = !isOn ? 'Actively polling groups' : 'Monitoring is paused';
    document.getElementById('status-dot').className = 'status-dot ' + (!isOn ? 'online' : 'offline');
    toast(isOn ? 'Monitoring paused' : 'Monitoring started');
  } catch(e) { toast('Error: ' + e.message); }
}

function openDashboard() {
  chrome.tabs.create({ url: SENTINEL_URL });
}

async function disconnect() {
  if (!confirm('Disconnect from SENTINEL? Your dashboard connection will be cleared.')) return;
  await chrome.storage.local.clear();
  showScreen('setup');
  document.getElementById('status-dot').className = 'status-dot';
  toast('Disconnected');
}

// ── BOOT ───────────────────────────────────────────────────────────────────────
async function init() {
  const { connected, accountInfo } = await chrome.storage.local.get(['connected', 'accountInfo']);

  if (connected && accountInfo) {
    try {
      const { profileId } = await chrome.storage.local.get('profileId');
      const pidParam = profileId ? `?profile_id=${profileId}` : '';
      const status = await sentinelFetch('GET', `/api/status${pidParam}`);

      if (status.hasCredential) {
        await loadDashboard(accountInfo);
        showScreen('dashboard');
      } else {
        await redetectRoblox();
      }
    } catch(e) {
      await loadDashboard(accountInfo);
      showScreen('dashboard');
    }
  } else {
    showScreen('setup');
    document.getElementById('status-dot').className = 'status-dot offline';
  }
}

// ── EVENT LISTENERS ───────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('connect-code-input').addEventListener('input', function() {
    this.value = this.value.replace(/[^0-9]/g, '');
  });
  document.getElementById('btn-connect').addEventListener('click', connectRoblox);
  document.getElementById('monitor-toggle').addEventListener('click', toggleMonitor);
  document.getElementById('btn-open-dashboard').addEventListener('click', openDashboard);
  document.getElementById('btn-disconnect').addEventListener('click', disconnect);

  init();
});
