# SENTINEL Chrome Extension

## What it does
- **One-click connect** — reads your `.ROBLOSECURITY` cookie from your active Roblox browser session and sends it to your SENTINEL server automatically. No DevTools needed.
- **Mini dashboard** — view stats, recent activity, and toggle monitoring on/off without opening the full dashboard.
- **Push notifications** — get notified when a new asset is archived, even when the dashboard isn't open.
- **Quick link** — open your full SENTINEL dashboard in one click.

## How to install (Developer Mode)
1. Go to `chrome://extensions`
2. Enable **Developer Mode** (top right toggle)
3. Click **Load unpacked**
4. Select this `sentinel-extension/` folder
5. The SENTINEL icon will appear in your toolbar

## Setup
1. Make sure you're logged into **roblox.com** on your **bot/mod account** (not your main)
2. Click the SENTINEL extension icon
3. Enter your SENTINEL dashboard URL (e.g. `https://sentinel-xxxx.onrender.com`)
4. Click **Connect Roblox to SENTINEL**
5. Done — your cookie is sent to the server automatically

## Important
- **Always use a dedicated bot account**, never your main
- The extension reads your `.ROBLOSECURITY` cookie and sends it to YOUR OWN SENTINEL server
- No data is sent anywhere else
- You can disconnect at any time from the extension popup

## Before publishing to Chrome Web Store
1. Replace `sentinel-xxxx.onrender.com` in `manifest.json` → `host_permissions` with your actual Render URL
2. Create real 16x16, 48x48, and 128x128 PNG icons in the `icons/` folder
3. Submit for Chrome Web Store review

## Files
```
sentinel-extension/
├── manifest.json    ← Extension config, permissions
├── popup.html       ← The popup UI (mini dashboard)
├── background.js    ← Background polling + notifications
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```
